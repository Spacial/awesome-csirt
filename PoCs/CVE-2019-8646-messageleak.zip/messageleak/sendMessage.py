import frida
import sys
import subprocess
import time


receiver = "TARGET"
exit = False

def on_message(message, data):
    global exit
    if message['type'] == 'send':
        payload = message['payload']
        if payload == "DONE":
            print("done")
            exit = True
            return
#print(payload)
    else:
        print(message)


#session = frida.get_usb_device().attach("imagent")

session = frida.attach("imagent")
code = open('injectMessage.js', 'r').read()
script = session.create_script(code);
script.on("message", on_message)
script.load()

# Send a message through apple script. Our hook will detect it and replace it before sending.
subprocess.call(["osascript", "sendMessage.applescript", receiver, "REPLACEME"])

while not exit:
    time.sleep(0.1)
