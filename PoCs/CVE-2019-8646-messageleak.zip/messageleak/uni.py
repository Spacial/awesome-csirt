from urllib.parse import unquote
import sys



def expand(s):
	q = bytearray(b"")
	i = 0

	while i < len(s):

		if s[i] == ord('\\') and s[i+1]== ord('U'):
			cur_char = s[i+2:i+6]
			n = int(cur_char[2:], 16)
			o = int(cur_char[0:2], 16)
			q.append(n)
			q.append(o)
			i = i + 6
		else:
			q.append(s[i])
			q.append(0)
			i = i + 1
	return bytes(q)


f = open(sys.argv[1], 'rb')

w = f.read()


unisec1 = w[0:w.find(ord('%'))]

urlsec = w[w.find(ord('%')):w.rfind(ord('%'))+3]

unisec2 = w[w.rfind(ord('%'))+3:]


i = 0
curr = 777
decurl = urlsec
while i < len(decurl):
	if decurl[i] == ord('%'):
		i = i + 3
		curr = 888
	elif decurl[i] == ord('\\') and decurl[i+1] == ord('U'):
		i = i + 6
		curr = 999
	else:
		if decurl[i] == curr:
			print("removing")
			print(hex(curr))
			print(hex(i))
			decurl = decurl[:i]+decurl[i+1:]
			curr = 555
		else:
			curr = decurl[i]
			i = i + 1
			 
decurl = unquote(decurl.decode(encoding='utf-8', errors='strict'))



decurl = decurl.encode('utf-16-le')

lc1 = 777
lc2 = 777
i=0
while i < len(decurl):

	if decurl[i] == ord('\\') and decurl[i+2]== ord('U'):
        	cur_char = decurl[i+4:i+12].decode('utf-16-le')
        	n = int(cur_char[2:], 16)
        	o = int(cur_char[0:2], 16)
        	if lc1 ==n and lc2 == o:
        		t = bytearray(decurl[:i])
        		t = t + bytearray(decurl[i+12:])
        		decurl = bytes(t)
        		
        	else:		
        		t = bytearray(decurl[:i])
        		lc1 = n
        		lc2 = o
        		t.append(n) 
        		t.append(o)
        		t = t + bytearray(decurl[i+12:])
        		decurl = bytes(t)
        		i = i + 2
	else:
		lc1 = 778
		lc2 = 778
		i = i + 1

u1 = expand(unisec1)
print(u1)
u2 = expand(unisec2)


f= open(sys.argv[2], 'wb')
f.write(u1+decurl+u2)
print(len(u1))
print(len(decurl))
print(len(u2))
f.close()
