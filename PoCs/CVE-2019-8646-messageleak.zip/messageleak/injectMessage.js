// Whether the serialized outgoing message should be replaced entirely.
var replaceSerializedMessage = false;

// Create the replacement data.
var dataLen = 0x100;
var rawData = new Uint8Array(dataLen);
for (var i = 0; i < dataLen; i++)
    rawData[i] = 0x41;
var buffer = Memory.alloc(dataLen);
buffer.writeByteArray(rawData.buffer);
var replacementData = ObjC.classes.NSData.dataWithBytes_length_(buffer, dataLen);



// Hook the message serialization routine.
var jw_encode_dictionary_addr = Module.getExportByName(null, "JWEncodeDictionary");
send("Hooking JWEncodeDictionary" + jw_encode_dictionary_addr);
Interceptor.attach(jw_encode_dictionary_addr, {
    onEnter: function(args) {
       var dict = ObjC.Object(args[0]);
        if (dict == null) {
            return;
        }

        send(dict.toString())

        var t = dict.objectForKey_("t")
        if (t == null) {
            return;
        }

        if (t == "REPLACEME") {
 
  
                   
                   console.log(dict);
                   var newDict = ObjC.classes.NSMutableDictionary.dictionaryWithCapacity_(dict.count());
                   var d = ObjC.classes.NSData.dataWithContentsOfFile_("FULL PATH HERE/obj");
                   console.log(d);

                   newDict.setObject_forKey_("com.apple.messages.MSMessageExtensionBalloonPlugin:0000000000:com.apple.Handwriting.HandwritingProvider", "bid");
  
                   
                   newDict.setObject_forKey_(d, "bp");

                   
                   newDict.setObject_forKey_(8, "gv");
                   newDict.setObject_forKey_(0, "pv");
                   newDict.setObject_forKey_(1, "v");
                   newDict.setObject_forKey_("FAA29682-27A6-498D-8170-CC92F2077441", "gid");
                   newDict.setObject_forKey_(d, "bp");
                   
                   newDict.setObject_forKey_("CB2F0B8D-84F6-480E-9079-27DA53E14EBD", "r");

                   
                   
                   newDict.setObject_forKey_(1, "v");
                   
                   newDict.setObject_forKey_("hello", "t");
                   args[0] = newDict.handle;
                   
                   send("DONE");
        }
    },

    onLeave: function(retval) {
        if (replaceSerializedMessage) {
            console.log("replacing")
            retval.replace(replacementData);
            replaceSerializedMessage = false;
        }
    }
});

